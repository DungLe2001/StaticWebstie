My name is Dung Anh Le (s3915085).

Guide:
	My website contains 5 pages in total, first page is the homepage, this page will illustrate 4 required pages which are CV, Project, ContactMe and Blog. 
	Click on the buttons, it will direct you to every listed pages.
	The reason I created a homepage even though it is not required, because I do not want all the data listed on 1 single page, it would be a mess if I did that.
	So creating a homepage will solve that problem. 

URL link to my website: https://github.com/DungLe2001/StaticWebstie.git
			https://dungle2001.github.io/StaticWebstie/

